#include"Inicio.h"
using namespace std;
using namespace cadenasDeMarkov;
void main() {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew Inicio());
}
